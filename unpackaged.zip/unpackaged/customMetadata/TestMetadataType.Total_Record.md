<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Total Record</label>
    <protected>false</protected>
    <values>
        <field>AccountId__c</field>
        <value xsi:type="xsd:string">Id</value>
    </values>
    <values>
        <field>Checkbox_field__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>Date_field__c</field>
        <value xsi:type="xsd:date">2018-03-15</value>
    </values>
    <values>
        <field>Date_time_field__c</field>
        <value xsi:type="xsd:dateTime">2018-03-16T18:30:00.000Z</value>
    </values>
    <values>
        <field>Metadata_Relationship__c</field>
        <value xsi:type="xsd:string">Account</value>
    </values>
    <values>
        <field>Percent_field__c</field>
        <value xsi:type="xsd:double">45.0</value>
    </values>
    <values>
        <field>Phone_field__c</field>
        <value xsi:type="xsd:string">666666666</value>
    </values>
    <values>
        <field>Picklist_field__c</field>
        <value xsi:type="xsd:string">Value2</value>
    </values>
    <values>
        <field>Test_Field__c</field>
        <value xsi:type="xsd:string">Text field</value>
    </values>
    <values>
        <field>Text_Area_Long_field__c</field>
        <value xsi:type="xsd:string">Text Area Long Field</value>
    </values>
    <values>
        <field>Text_Area_field__c</field>
        <value xsi:type="xsd:string">Text Area field</value>
    </values>
    <values>
        <field>URL_field__c</field>
        <value xsi:type="xsd:string">http://www.everis.com</value>
    </values>
    <values>
        <field>email_field__c</field>
        <value xsi:type="xsd:string">email@everis.com</value>
    </values>
    <values>
        <field>number_field__c</field>
        <value xsi:type="xsd:double">4.0</value>
    </values>
</CustomMetadata>
