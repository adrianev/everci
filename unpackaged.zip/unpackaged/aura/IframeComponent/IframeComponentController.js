({
	myAction : function(component, event, helper) {
		
	},
    handleClick : function(component, event, helper) {
		window.print();
	}
})