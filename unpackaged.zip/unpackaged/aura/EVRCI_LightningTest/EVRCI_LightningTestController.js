({
	myAction : function(component, event, helper) {
		/*cambio test*/
	}
})