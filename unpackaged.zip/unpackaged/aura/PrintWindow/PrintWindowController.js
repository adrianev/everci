({
	handleClick : function(component, event, helper) {
		window.print();
	}
})